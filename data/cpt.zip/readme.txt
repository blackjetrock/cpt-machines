These are disks for the CPT8000 end CPT9000 wordprocessing systems.

CPT8000_WP is the German version of the wordprocessor for the CPT8000 ( Presumed, untested !)
Originally a DSDD 8" Floppy


CPT9000_Setup   is a 5.25" setup   disk for the CPT9000 ( verified )
CPT9000_install is a 5.25" install disk for the CPT9000 ( verified )

The CPT9000 is a MSDOS compatible AT with a portrait-oriented B/W CRT, intended as a WP system.

All disks are German.


